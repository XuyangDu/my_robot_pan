# 常用工具 common

## 执行命令行命令 executeCmd.h

## 获取用户名 getUser.h

## 判断各种数据是否相等 judgeEqual.h

## 裁切vector cutVector.h

# CRC校验 CRC

# 大寰夹爪SDK DHGripper

# 有限状态机 FSM

# 低通滤波器 LPFilter

# 数学工具 mathLib

# 一组串行电机 MotorSerialChain

# 多线程 multiThread

# 绘制折线图 pyPlot

# 平滑的S-曲线 sCurve

# 时间、定时器 time

# 类型转换 typeTrans

# 宇树电机通信SDK unitreeMotor

# 硬件通信大类 IOPort
√ 阻塞与非阻塞通信

## 串口通信 SerialPort

## UDP通信 UDPPort

# 人机交互大类 CmdPanel
√ 最好直接输入枚举类中各个项的向量

√ 克服虚按，保证按一次键只会输出一次状态

√ 支持多通道获取state，保证每个通道都能得到状态，不会被其他通道抢先

  检测StateAction的重复按键

控制量类型：

    √ 触发量：如切换有限状态机的状态

    √ 积分量：如旋转角度，需要可以设置上下限

    切换量：如夹爪换向，按下某键，即顺序进入下一(归入触发量)
## 键盘交互 Keyboard
√ 支持上下左右方向键

√ 读取输入字符串
## 宇树手柄交互 UnitreeJoystick 
