#ifndef STATEENUM_H
#define STATEENUM_H

enum S_INIT_STATES{
    S_INIT_NOT = 0,         // Need to be initialized    
    S_INIT_FINISHED = 1,    // Initialize finished
    S_INIT_DOING = 2,       // Initializing
};

enum S_GRIP_STATES{
    S_GRIP_MOVING = 0,      // gripper finger is moving
    S_GRIP_ARRIVED = 1,     // gripper finger arrived target position
    S_GRIP_CAUGHT = 2,      // gripper caught a object
    S_GRIP_DROPPED = 3,     // object dropped
};

#endif  // STATEENUM_H