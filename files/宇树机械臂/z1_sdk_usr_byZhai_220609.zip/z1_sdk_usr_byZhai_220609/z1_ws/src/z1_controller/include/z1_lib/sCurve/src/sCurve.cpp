#include "sCurve/SCurve.h"
#include "time/timeMarker.h"

void SCurve::setSCurve(double deltaQ, double dQMax, double ddQMax, double dddQMax){
    _vMax = dQMax / fabs(deltaQ);
    _aMax = ddQMax / fabs(deltaQ);
    _J    = dddQMax / fabs(deltaQ);

    _T[0] = _T[2] = _T[4] = _T[6] = _aMax / _J;
    _T[1] = _T[5] = _vMax / _aMax - _T[0];

    if(_T[1] < 0){
        // std::cout << "_T[1] < 0" << std::endl;
        _aMax = pow(_J*_vMax, 0.5);
        _T[0] = _T[2] = _T[4] = _T[6] = _aMax / _J;
        _T[1] = _T[5] = 0;
    }
    _setFunc();

    _T[3] = (1.0 - 2.0*_s2) / _vMax;

    if(_T[3] < 0){
        // std::cout << "_T[3] < 0" << std::endl;
        _aMax = pow(0.5*_J*_J, 1.0/3.0);
        _T[0] = _T[2] = _T[4] = _T[6] = _aMax / _J;
        _T[1] = _T[5] = 0;
        _vMax = _aMax * _T[0];
        _setFunc();
        _T[3] = 0;
    }

    _s3 = _s2 + _vMax*_T[3];
    _s4 = _s3 + _vMax*_T[4] - _J*pow(_T[4],3)/6.0;
    _s5 = _s4 + (_vMax - _v0)*_T[5] - 0.5*_aMax*pow(_T[5],2);
    _s6 = _s5 + (_vMax - _v1)*_T[6] - 0.5*_aMax*pow(_T[6],2) + _J*pow(_T[6],3)/6.0;

    _t[0] = _T[0];
    for(int i(1); i<7; ++i){
        _t[i] = _t[i-1] + _T[i];
    }

    restart();
}

void SCurve::_setFunc(){
//     _T[0] = _T[2] = _T[4] = _T[6] = _aMax / _J;
//     _T[1] = _T[5] = _vMax / _aMax - _T[0];

//     if(_T[1] < 0){
// std::cout << "_T[1] < 0" << std::endl;
//         _aMax = pow(_J*_vMax, 0.5);
//         _T[0] = _T[2] = _T[4] = _T[6] = _aMax / _J;
//         _T[1] = _T[5] = 0;
//     }

    _v0 = 0.5 * pow(_aMax, 2) / _J;
    _v1 = _v0 + _aMax*_T[1];

    _s0 = pow(_aMax, 3) / (6*pow(_J, 2));
    _s1 = _s0 + _v0*_T[1] + 0.5*_aMax*pow(_T[1],2);
    _s2 = _s1 + _v1*_T[2] + 0.5*_aMax*pow(_T[2],2) - _J*pow(_T[2],3)/6.0;

    // std::cout << "_s2: " << _s2 << std::endl;
}

int SCurve::_getSegment(double t){
    if(t < _t[0]){
        return 0;
    }else{
        int id = 1;
        for(int i(1); i<7; ++i){
            if((_t[i-1]<=t)&&(t<_t[i])){
                return id;
            }
            ++id;
        }
    }
    return 7;   // 7 means over full time
}

double SCurve::getDDs(double t){
    switch (_getSegment(t))
    {
    case 0:
        return _J*t;
        break;
    case 1:
        return _aMax;
        break;
    case 2:
        return _aMax-_J*(t-_t[1]);
        break;
    case 3:
        return 0;
        break;
    case 4:
        return -_J*(t-_t[3]);
        break;
    case 5:
        return -_aMax;
        break;
    case 6:
        return -_aMax + _J*(t-_t[5]);
        break;
    default:
        return 0;
        break;
    }
}

double SCurve::getDs(double t){
    switch (_getSegment(t))
    {
    case 0:
        return 0.5*_J*pow(t,2);
        break;
    case 1:
        return _v0 + _aMax*(t-_t[0]);
        break;
    case 2:
        return _v1 + 0.5*(2*_aMax-_J*(t-_t[1]))*(t-_t[1]);
        break;
    case 3:
        return _vMax;
        break;
    case 4:
        return _vMax - 0.5*_J*pow((t-_t[3]),2);
        break;
    case 5:
        return _vMax - _v0 - _aMax*(t-_t[4]);
        break;
    case 6:
        // return _vMax - _v1 - 0.5*(2*_aMax-_J*(t-_t[5]))*(t-_t[5]);
        return _vMax - _v1 - _aMax*(t-_t[5]) + 0.5*_J*pow((t-_t[5]),2);
        break;
    default:
        return 0;
        break;
    }
}

double SCurve::gets(double t){
    switch (_getSegment(t))
    {
    case 0:
        return _J*pow(t,3)/6.0;
        break;
    case 1:
        return _s0 + _v0*(t-_t[0]) + 0.5*_aMax*pow((t-_t[0]),2);
        break;
    case 2:
        return _s1 + _v1*(t-_t[1]) + 0.5*_aMax*pow((t-_t[1]),2) - _J*pow((t-_t[1]),3)/6.0;
        break;
    case 3:
        return _s2 + _vMax*(t-_t[2]);
        break;
    case 4:
        return _s3 + _vMax*(t-_t[3]) - _J*pow((t-_t[3]),3)/6.0;
        break;
    case 5:
        return _s4 + (_vMax - _v0)*(t-_t[4]) - 0.5*_aMax*pow((t-_t[4]),2);
        break;
    case 6:
        return _s5 + (_vMax - _v1)*(t-_t[5]) - 0.5*_aMax*pow((t-_t[5]),2) + _J*pow((t-_t[5]),3)/6.0;
        break;
    default:
        return 1.0;
        break;
    }
}

double SCurve::getT(){
    if(isfinite(_t[6])){
        return _t[6];
    }else{
        return 0.0;
    }
}

double SCurve::_runTime(){
    if(!_started){
        _started = true;
        _startTime = getTimeSecond();
    }
    return getTimeSecond() - _startTime;
}

void SCurve::restart(){
    _started = false;
}

double SCurve::gets(){
    return gets(_runTime());
}

double SCurve::getDs(){
    return getDs(_runTime());
}

double SCurve::getDDs(){
    return getDDs(_runTime());
}