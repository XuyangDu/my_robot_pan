# PyPlot:
need Python2, numpy, CMake 3.14

## PyPlot CMakeLists.txt:

find_package(Python2 COMPONENTS Interpreter Development NumPy)

include_directories(
    ${Python2_INCLUDE_DIRS}
    ${Python2_NumPy_INCLUDE_DIRS}
)

target_link_libraries(**** Python2::Python Python2::NumPy)

# target_include_directories(**** PRIVATE ${Python2_INCLUDE_DIRS} ${Python2_NumPy_INCLUDE_DIRS})