#include "typeTrans.h"
#include <iostream>


/* combined test */
int main(){
    Eigen::Vector3d v3;
    Eigen::Vector2d v2;
    Eigen::Matrix2d m2;
    double          d1;

    v3 << 3.1, 3.2, 3.3;
    v2 << 2.1, 2.2;
    m2 << 4.1, 4.2, 4.3, 4.4;
    d1 = 5.5;

    std::vector<double> vec;

    typeTrans::combineToVector(vec, v3, v2, m2, d1);

    Eigen::Vector3d newv3;
    Eigen::Vector2d newv2;
    Eigen::Matrix2d newm2;
    double          newd1;

    typeTrans::extractVector(vec, newv3, newv2, newm2, newd1);

    std::cout << "newv3: " << newv3.transpose() << std::endl;
    std::cout << "newv2: " << newv2.transpose() << std::endl;
    std::cout << "newm2: " << newm2 << std::endl;
    std::cout << "newd1: " << newd1 << std::endl;

    return 0;
}


// int main(){
//     /* To Vector */
//     Eigen::Matrix2d mat22;
//     Eigen::Vector2d vec2;
//     std::vector<double> vec;
//     double a, b, c;

//     a = 1;
//     b = 11;
//     vec2 << 100, 200;
//     mat22 << 1.1, 1.2, 1.3, 1.4;

//     // typeTrans::combineToVector(vec, 1.0, 4.0, 3.0, 5.0, mat22, 1.0);
//     typeTrans::combineToVector(vec, a, b, vec2, mat22);
//     // typeTrans::combineToVector(vec, vec2);

//     for(int i(0); i<vec.size(); ++i){
//         std::cout << vec.at(i) << ", ";
//     }

//     std::cout << std::endl;

//     /* from Vector to variables */
//     double newA, newB;
//     Eigen::Matrix2d newMat22;
//     Eigen::Vector2d newVec2;

//     typeTrans::extractVector(vec, newA, newB, newVec2, newMat22);

//     std::cout << "newA: " << newA << ", newB: " << newB << std::endl;
//     std::cout << newMat22 << std::endl;
//     std::cout << newVec2.transpose() << std::endl;
// }