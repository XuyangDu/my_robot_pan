#include "pyPlot/PyPlot.h"
#include "sCurve/SCurve.h"

int main(){
    PyPlot plot;
    plot.addPlot("DDs", 1);
    plot.addPlot("Ds", 1);
    plot.addPlot("diffS", 1);
    plot.addPlot("diffDs", 1);
    plot.addPlot("s", 1);

    SCurve curve;
    double angle = 0.3;
    // curve.setSCurve(angle, 2, 2, 4);
    // curve.setSCurve(5, 1.8, 2, 2);
    // curve.setSCurve(1, 1.8, 2, 2);

    curve.setSCurve(angle, 0.2, 0.2, 1.0);

    double dt = 0.01;
    double pastS, s;
    double pastDs, Ds;
    double diffS, diffDs;

    for(int i(0); i<300; ++i){
        s = curve.gets();
        Ds = curve.getDs();
        diffS = (s - pastS) / dt;
        diffDs = (Ds - pastDs) / dt;

        plot.addFrame("DDs",  angle*curve.getDDs());
        plot.addFrame("Ds",  angle*Ds);
        plot.addFrame("diffS",  angle*diffS);
        plot.addFrame("diffDs",  angle*diffDs);
        plot.addFrame("s",  angle*s);

        pastS = s;
        pastDs = Ds;

        usleep((long long)(1e6*dt));
    }

    // curve.restart();
    // curve.setSCurve(angle, 2, 2, 4);

    // for(int i(0); i<200; ++i){
    //     s = curve.gets();
    //     Ds = curve.getDs();
    //     diffS = (s - pastS) / dt;
    //     diffDs = (Ds - pastDs) / dt;

    //     plot.addFrame("DDs",  angle*curve.getDDs());
    //     plot.addFrame("Ds",  angle*Ds);
    //     plot.addFrame("diffS",  angle*diffS);
    //     plot.addFrame("diffDs",  angle*diffDs);
    //     plot.addFrame("s",  angle*s);

    //     pastS = s;
    //     pastDs = Ds;

    //     usleep((long long)(1e6*dt));
    // }

    plot.showPlotAll();

    return 0;
}




// int main(){
//     PyPlot plot;
//     plot.addPlot("DDs", 1);
//     plot.addPlot("Ds", 1);
//     plot.addPlot("diffS", 1);
//     plot.addPlot("diffDs", 1);
//     plot.addPlot("s", 1);

//     SCurve curve;
//     double angle = 5;
//     curve.setSCurve(angle, 2, 2, 4);
//     // curve.setSCurve(5, 1.8, 2, 2);
//     // curve.setSCurve(1, 1.8, 2, 2);

//     double time = 0;
//     double dt = 0.001;
//     double pastS, s;
//     double pastDs, Ds;
//     double diffS, diffDs;

//     while(time < 5){
//         s = curve.gets(time);
//         Ds = curve.getDs(time);
//         diffS = (s - pastS) / dt;
//         diffDs = (Ds - pastDs) / dt;

//         plot.addFrame("DDs", time, angle*curve.getDDs(time));
//         plot.addFrame("Ds", time, angle*Ds);
//         plot.addFrame("diffS", time, angle*diffS);
//         plot.addFrame("diffDs", time, angle*diffDs);
//         plot.addFrame("s", time, angle*s);

//         pastS = s;
//         pastDs = Ds;
//         time += dt;
//     }

//     plot.showPlotAll();

//     return 0;
// }