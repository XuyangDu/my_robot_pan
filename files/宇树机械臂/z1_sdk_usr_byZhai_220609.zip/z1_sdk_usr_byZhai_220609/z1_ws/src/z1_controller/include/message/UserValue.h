#ifndef USERVALUE_H
#define USERVALUE_H

#include "mathLib/mathTypes.h"
#include "typeTrans/typeTrans.h"
#include "common/cutVector.h"
#include <vector>

struct UserValue{
    Vec6 moveAxis;
    double gripperPos;
    // double gripperTau;

    void setData(std::vector<double> rawData){
#ifdef CTRL_BY_SDK
        if(rawData.size() != 7){
            std::cout << "[ERROR] UserValue::setData, the size of rawDate is " << rawData.size() << " but not 7" << std::endl;
        }
        gripperPos = rawData.at(6);
        rawData = cutVector(rawData, 0, 6);
        moveAxis = typeTrans::getValue(rawData, moveAxis);
#endif
#ifdef CTRL_BY_KEYBOARD
        if(rawData.size() != 7){
            std::cout << "[ERROR] UserValue::setData, the size of rawDate is " << rawData.size() << " but not 7" << std::endl;
        }
        gripperPos = rawData.at(6);
        rawData = cutVector(rawData, 0, 6);
        moveAxis = typeTrans::getValue(rawData, moveAxis);
#endif
#ifdef CTRL_BY_JOYSTICK
        if(rawData.size() != 1){
            std::cout << "[ERROR] UserValue::setData, the size of rawDate is " << rawData.size() << " but not 1" << std::endl;
        }
        gripperPos = rawData.at(0);
#endif
    }

    UserValue(){
        setZero();
    }
    void setZero(){
        moveAxis.setZero();
        gripperPos = 0;
        // gripperTau = 0;
    }
};

#endif