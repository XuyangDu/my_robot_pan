#include "CSVTool.h"
#include <Eigen/Dense>
#include <string>

/* read and write */
// int main(){

//     CSVTool csv("csvExp.csv");

//     std::vector<double> val, newVal;

//     csv.getLine("c", val);

//     // for(int i(0); i<val.size(); ++i){
//     //     std::cout << val.at(i) << ", ";
//     // }

//     val.at(0) = 0.0;

//     csv.modifyLine("c", val);

//     newVal.push_back(123.5);
//     csv.modifyLine("c", newVal);
//     // csv.modifyLine("newLine", newVal);
//     // csv.modifyLine("newLine", newVal, true);

//     csv.saveFile();

//     std::vector<double> stdVec;
//     Eigen::Vector2d vec2;
//     double value3;

//     csv.getLine("a", stdVec);
//     for(int i(0); i<stdVec.size(); ++i){
//         std::cout << stdVec.at(i) << ", ";
//     }std::cout << std::endl;

//     typeTrans::extractVector(stdVec, vec2, value3);

//     // csv.getLineDirect("a", vec2, value3);


//     std::cout << "vec2: " << vec2.transpose() << std::endl;
//     std::cout << "value3: " << value3 << std::endl;

//     return 0;
// }


/* clear and dump */
int main(){
    // CSVTool csv("../notExist.csv", FileType::READ_WRITE);
    CSVTool csv("../empty.csv", FileType::CLEAR_DUMP);

    for(int i(0); i<15; ++i){
        csv.modifyLineDirect(std::to_string(i), true, i, i);
    }

    csv.saveFile();

    return 0;
}