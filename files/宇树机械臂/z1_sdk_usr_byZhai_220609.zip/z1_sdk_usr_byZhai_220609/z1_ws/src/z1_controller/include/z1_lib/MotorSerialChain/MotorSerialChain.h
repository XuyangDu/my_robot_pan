#ifndef MOTORSERIALCHAIN_H
#define MOTORSERIALCHAIN_H

#include "serialPort/SerialPort.h"
#include <thread>
#include <mutex>

class MotorSerialChain{
public:
    MotorSerialChain(std::string serialName, int motorNum, 
        std::vector<int> motorID, MotorType motorType = MotorType::A1Go1);
    ~MotorSerialChain();
    void setMotorCmd(const std::vector<double> &q, const std::vector<double> &qd,
        const std::vector<double> &tau, const std::vector<double> &kp, 
        const std::vector<double> &kd);
    void getMotorState(std::vector<double> &q, std::vector<double> &qd,
        std::vector<double> &qdd, std::vector<double> &tau);
    void run();
private:
    void _generateCmd();
    void _extractState();
    // void _comm();

    SerialPort *_port;
    int _motorNum;
    std::vector<int> _motorID;
    MotorType _motorType;

    std::mutex _cmdLock;
    std::mutex _stateLock;

    std::vector<MOTOR_send> _motorCmd;
    std::vector<double> _cmdQ;
    std::vector<double> _cmdQd;
    std::vector<double> _cmdTau;
    std::vector<double> _cmdKp;
    std::vector<double> _cmdKd;

    std::vector<MOTOR_recv> _motorState;
    std::vector<double> _stateQ;
    std::vector<double> _stateQd;
    std::vector<double> _stateQdd;
    std::vector<double> _stateTau;
};

#endif  // MOTORSERIALCHAIN_H