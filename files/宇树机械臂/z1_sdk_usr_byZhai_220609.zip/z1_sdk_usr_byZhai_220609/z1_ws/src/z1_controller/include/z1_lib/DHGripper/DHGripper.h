#ifndef DHGRIPPER_H
#define DHGRIPPER_H

#include "serialPort/SerialPort.h"
#include "DHGripper/include/stateEnum.h"
#include "CRC/crc16.h"

/* 
大寰夹爪驱动，利用z1_lib串口程序，
大寰原装示例代码在高频收发命令时，会漏收字节
*/
class DHGripper{
public:
    DHGripper(SerialPort *serialPort, int gripperID = 1);
    ~DHGripper(){}
    bool Initialization();
    bool SetTargetPosition(int refpos);
    bool SetTargetForce(int force);
    bool SetTargetSpeed(int speed);

    bool GetInitState(int &i_state);
    bool GetGripState(int &g_state);
    bool GetCurrentPosition(int &curpos);
    bool GetTargetPosition(int &tarpos);
    bool GetTargetForce(int &curTarforce);
    bool GetTargetSpeed(int &curTarpos);

private:
    bool _readRegisterFunc(int index, int &value);
    bool _writeRegisterFunc(int index, int value);
    SerialPort *_serialPort;
    int _gripperID;
};

inline DHGripper::DHGripper(SerialPort *serialPort, int gripperID)
         :_serialPort(serialPort), _gripperID(gripperID){
             
    int initstate = 0;
    GetInitState(initstate);
    if(initstate != S_INIT_STATES::S_INIT_FINISHED){
        Initialization();
        std::cout<< " Send grip init " << std::endl;

        //wait for gripper initialization
        initstate = 0;
        std::cout<< " Send grip GetInitState " << std::endl;
        while(initstate != S_INIT_STATES::S_INIT_FINISHED )
            GetInitState(initstate); 
        std::cout<< " Send grip GetInitState "<< initstate << std::endl;
    }
}

inline bool DHGripper::GetInitState(int &i_state){
     return _readRegisterFunc(0x0200,i_state);
}

inline bool DHGripper::GetGripState(int &g_state){
     return _readRegisterFunc(0x0201,g_state);
}

inline bool DHGripper::GetCurrentPosition(int &curpos){
    return _readRegisterFunc(0x0202,curpos);
}

inline bool DHGripper::GetTargetPosition(int &tarpos){
    return _readRegisterFunc(0x0103,tarpos);
}

inline bool DHGripper::GetTargetForce(int &curTarforce){
    return _readRegisterFunc(0x0101,curTarforce);
}

inline bool DHGripper::GetTargetSpeed(int &curTarpos){
    return _readRegisterFunc(0x0104,curTarpos);
}

inline bool DHGripper::Initialization(){
   return _writeRegisterFunc(0x0100,0xA5);
}

inline bool DHGripper::SetTargetPosition(int refpos){
    return _writeRegisterFunc(0x0103,refpos);
}

inline bool DHGripper::SetTargetForce(int force){
    return _writeRegisterFunc(0x0101,force);
}

inline bool DHGripper::SetTargetSpeed(int speed){
    return _writeRegisterFunc(0x0104,speed);
}

/* send 8 bytes, receive same 8 bytes */
inline bool DHGripper::_writeRegisterFunc(int index, int value){
    uint8_t send_buf[8];
    send_buf[0] = _gripperID;
    send_buf[1] = 0x06;
    send_buf[2] = (index>>8)&0xff;
    send_buf[3] = index&0xff;
    send_buf[4] = (value>>8)&0xff;
    send_buf[5] = value&0xff;
    uint16_t crc = crc16_core(send_buf,sizeof(send_buf)-2);
    send_buf[6] = crc&0xff;
    send_buf[7] = (crc>>8)&0xff;

    bool ret = false;
    int retrycount = 3;
    uint8_t rev_buf[32];

    _serialPort->resetSerial(8, 115200, 20000, BlockYN::NO, bytesize_t::eightbits,
                             parity_t::parity_none, stopbits_t::stopbits_one,
                             flowcontrol_t::flowcontrol_none);

    while(!ret){
        retrycount--;
        if(retrycount < 0){
            break;
        }

        if(!_serialPort->sendRecv(send_buf, rev_buf, sizeof(send_buf))){
            continue;
        }

        bool checkrev = true;
        for(int i=0;i<sizeof(send_buf);i++)
        {
            if(send_buf[i] != (unsigned char)rev_buf[i])
            {
                // std::cout << "def " <<(unsigned int)(unsigned char) send_buf[i]<<" "<<(unsigned int)(unsigned char) rev_buf[i];
                checkrev = false;      
                break;
            }
        }
        if(checkrev)
            ret = true;
    }

    return ret;
}

/* send 8 bytes, receive 7 bytes */
inline bool DHGripper::_readRegisterFunc(int index, int &value){
    uint8_t send_buf[8];
    send_buf[0] = _gripperID;
    send_buf[1] = 0x03;
    send_buf[2] = (index>>8)&0xff;
    send_buf[3] = index&0xff;
    send_buf[4] = 0x00;
    send_buf[5] = 0x01;
    uint16_t crc = crc16_core(send_buf,sizeof(send_buf)-2);
    send_buf[6] = crc&0xff;
    send_buf[7] = (crc>>8)&0xff;

    bool ret = false;
    int retrycount = 10;
    uint8_t rev_buf[32];

    _serialPort->resetSerial(7, 115200, 20000, BlockYN::NO, bytesize_t::eightbits,
                             parity_t::parity_none, stopbits_t::stopbits_one,
                             flowcontrol_t::flowcontrol_none);

    while(!ret){
        retrycount--;
        if(retrycount < 0){
            break;
        }

        if(!_serialPort->sendRecv(send_buf, rev_buf, sizeof(send_buf))){
            continue;
        }

        bool checkrev = true;
        uint16_t crc = crc16_core((uint8_t*)rev_buf,7-2);

        int revcrch = (unsigned int) (uint8_t)rev_buf[6];
        int revcrcl = (unsigned int) (uint8_t)rev_buf[5];
        uint16_t revcrc =  revcrch * 256 + revcrcl;

        if(crc != revcrc){
            checkrev = false;
        }
        if(rev_buf[0] != _gripperID || rev_buf[1] != 0x03){
            checkrev = false;
        }
        if(checkrev){
            value = ((rev_buf[4]&0xff)|(rev_buf[3]<<8));
            ret = true;
        }
    }
    return ret;
}

#endif  // DHGRIPPER_H