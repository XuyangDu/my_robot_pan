#include "DHGripper/DHGripper.h"

int main(){
    SerialPort serialPort("/dev/ttyUSB0");
    DHGripper gripper(&serialPort);

    // SerialPort serialPort1("/dev/ttyUSB0");
    // DHGripper gripper1(&serialPort1);

    // int initstate = 0;
    // gripper.GetInitState(initstate);
    // while(initstate != S_INIT_STATES::S_INIT_FINISHED){
    //     gripper.Initialization();
    //     gripper.GetInitState(initstate);
    // }

    /* 注释后会段错误，莫名其妙 */
    int initstate = 0;
    gripper.GetInitState(initstate);
    if(initstate != S_INIT_STATES::S_INIT_FINISHED)
    {
        gripper.Initialization();
        std::cout<< " Send grip init " << std::endl;

        //wait for gripper initialization
        initstate = 0;
        std::cout<< " Send grip GetInitState " << std::endl;
        while(initstate != S_INIT_STATES::S_INIT_FINISHED )
            gripper.GetInitState(initstate); 
        std::cout<< " Send grip GetInitState "<< initstate << std::endl;
    }


std::cout << "finished init" << std::endl;
    int state;

    gripper.SetTargetPosition(1000);
    do{
        gripper.GetGripState(state);
        usleep(10000);
    } while (state == S_GRIP_STATES::S_GRIP_MOVING);
std::cout << "finished 1000" << std::endl;
    gripper.SetTargetPosition(0);
    do{
        gripper.GetGripState(state);
        usleep(10000);
    } while (state == S_GRIP_STATES::S_GRIP_MOVING);    
std::cout << "finished 0" << std::endl;

    return 0;
}