// #include <fstream>
// #include <iostream>
// #include <string>
// #include <iomanip>

// int main(){
//     std::fstream inOut("csvExp.csv", std::fstream::ate | std::fstream::in | std::fstream::out);

//     if(!inOut){
//         std::cerr << "[ERROR] Unable to open the file" << std::endl;
//         return EXIT_FAILURE;
//     }

//     auto end_mark = inOut.tellg();
//     inOut.seekg(0, std::fstream::beg);
//     size_t cnt = 0;
//     std::string line;

//     inOut << std::fixed << std::setprecision(3);

//     while (inOut && inOut.tellg() != end_mark && getline(inOut, line)){
//         cnt += line.size() + 1;
//         auto mark = inOut.tellg();
//         inOut.seekp(0, std::fstream::end);

//         inOut << cnt;

//         if(mark != end_mark){
//             inOut << " ";
//         }
//         inOut.seekg(mark);
//     }

//     inOut.seekp(0, std::fstream::end);
//     inOut << "\n";

//     return 0;
// }

#include <algorithm>
#include <string>
#include <iostream>
#include <cctype>
  
int main()
{
    std::string str1 = "Text with some   spaces";
    str1.erase(std::remove(str1.begin(), str1.end(), ' '),
               str1.end());
    std::cout << str1 << '\n';
}