#include "LPFilter/LPFilter.h"
#include <math.h>
#include <iostream>

LPFilter::LPFilter(double samplePeriod, double cutFrequency, size_t valueCount)
        :_valueCount(valueCount){
    _weight = 1.0 / ( 1.0 + 1.0/(2.0 * M_PI * samplePeriod * cutFrequency) );
    _start  = false;
    _pastValue.resize(_valueCount);
}

void LPFilter::addValue(double &newValue){
    if(_valueCount != 1){
        std::cout << "[WARNING] LPFilter::addValue(double), the size of LPFilter is " << _valueCount << ", not 1" << std::endl;
    }

    if(!_start){
        _start = true;
        _pastValue.at(0) = newValue;
    }
    _pastValue.at(0) = _weight*newValue + (1-_weight)*_pastValue.at(0);
    newValue = _pastValue.at(0);
}

template <typename T>
void LPFilter::addValue(Eigen::MatrixBase<T> &eigenVec){
    if(eigenVec.rows() != _valueCount){
        std::cout << "[WARNING] LPFilter::addValue(eigneVec), the size of LPFilter is " << _valueCount << ", not " << eigenVec.rows() << std::endl;
    }

    if(!_start){
        _start = true;
        for(int i(0); i<_valueCount; ++i){
            _pastValue.at(i) = eigenVec(i);
        }
    }

    for(int i(0); i<_valueCount; ++i){
        _pastValue.at(i) = _weight*eigenVec(i) + (1-_weight)*_pastValue.at(i);
        eigenVec(i) = _pastValue.at(i);
    }
}

void LPFilter::addValue(std::vector<double> &vec){
    if(vec.size() != _valueCount){
        std::cout << "[WARNING] LPFilter::addValue(std::vector), the size of LPFilter is " << _valueCount << ", not " << vec.size() << std::endl;
    }

    if(!_start){
        _start = true;
        for(int i(0); i<_valueCount; ++i){
            _pastValue.at(i) = vec.at(i);
        }
    }

    for(int i(0); i<_valueCount; ++i){
        _pastValue.at(i) = _weight*vec.at(i) + (1-_weight)*_pastValue.at(i);
        vec.at(i) = _pastValue.at(i);
    }
}

// double LPFilter::getValue(){
//     return _pastValue;
// }

void LPFilter::clear(){
    _start = false;
}