#include "MotorSerialChain/MotorSerialChain.h"

MotorSerialChain::MotorSerialChain(std::string serialName, int motorNum, std::vector<int> motorID, MotorType motorType)
    :_motorNum(motorNum), _motorType(motorType){
    if(motorID.size() == motorNum){
        _motorID = motorID;
    }else{
        std::cout << "[ERROR] MotorSerialChain::MotorSerialChain, the size of motorID is " << motorID.size()
            << " but not " << motorNum << ".";
        exit(-1);
    }

    _port = new SerialPort(serialName);

    _motorCmd.resize(_motorNum);
    _cmdQ.resize(_motorNum);
    _cmdQd.resize(_motorNum);
    _cmdTau.resize(_motorNum);
    _cmdKp.resize(_motorNum);
    _cmdKd.resize(_motorNum);

    _motorState.resize(_motorNum);
    _stateQ.resize(_motorNum);
    _stateQd.resize(_motorNum);
    _stateQdd.resize(_motorNum);
    _stateTau.resize(_motorNum);
}

MotorSerialChain::~MotorSerialChain(){
    delete _port;
}

void MotorSerialChain::setMotorCmd(const std::vector<double> &q, const std::vector<double> &qd,
        const std::vector<double> &tau, const std::vector<double> &kp, 
        const std::vector<double> &kd){
    if(q.size() != _motorNum){
        std::cout << "[ERROR] MotorSerialChain::setMotorCmd, the size of q is "
            << q.size() << ", but not " << _motorNum;
        exit(-1);
    }
    if(qd.size() != _motorNum){
        std::cout << "[ERROR] MotorSerialChain::setMotorCmd, the size of qd is "
            << qd.size() << ", but not " << _motorNum;
        exit(-1);
    }
    if(tau.size() != _motorNum){
        std::cout << "[ERROR] MotorSerialChain::setMotorCmd, the size of tau is "
            << tau.size() << ", but not " << _motorNum;
        exit(-1);
    }
    if(kp.size() != _motorNum){
        std::cout << "[ERROR] MotorSerialChain::setMotorCmd, the size of kp is "
            << kp.size() << ", but not " << _motorNum;
        exit(-1);
    }
    if(kd.size() != _motorNum){
        std::cout << "[ERROR] MotorSerialChain::setMotorCmd, the size of kd is "
            << kd.size() << ", but not " << _motorNum;
        exit(-1);
    }

    _cmdLock.lock();
    _cmdQ = q;
    _cmdQd = qd;
    _cmdTau = tau;
    _cmdKp = kp;
    _cmdKd = kd;
    _cmdLock.unlock();
}

void MotorSerialChain::getMotorState(std::vector<double> &q, std::vector<double> &qd,
    std::vector<double> &qdd, std::vector<double> &tau){
    _stateLock.lock();
    q = _stateQ;
    qd = _stateQd;
    qdd = _stateQdd;
    tau = _stateTau;
    _stateLock.unlock();
}

void MotorSerialChain::_generateCmd(){
    _cmdLock.lock();
    for(int i(0); i<_motorNum; ++i){
        _motorCmd.at(i).id = _motorID.at(i);
        _motorCmd.at(i).mode = 10;
        _motorCmd.at(i).Pos = _cmdQ.at(i);
        _motorCmd.at(i).W = _cmdQd.at(i);
        _motorCmd.at(i).T = _cmdTau.at(i);
        _motorCmd.at(i).K_P = _cmdKp.at(i);
        _motorCmd.at(i).K_W = _cmdKd.at(i);
    }
    _cmdLock.unlock();
}

void MotorSerialChain::_extractState(){
    _stateLock.lock();
    for(int i(0); i<_motorNum; ++i){
        _stateQ.at(i) = _motorState.at(i).Pos;
        _stateQd.at(i) = _motorState.at(i).W;
        _stateQdd.at(i) = _motorState.at(i).Acc;
        _stateTau.at(i) = _motorState.at(i).T;
    }
    _stateLock.unlock();
}

void MotorSerialChain::run(){
    _generateCmd();

    if(_port->sendRecv(_motorCmd, _motorState)){
        _extractState();
    }
}