#include "PyPlot.h"

// PyPlot多个静态图测试
int main(){
    PyPlot plot;
    plot.addPlot("test", 1, std::vector<std::string>{"y"});                         // 输入标量
    plot.addPlot("testArray", 3, std::vector<std::string>{"y1", "y2", "y3"});       // 输入数组
    plot.addPlot("testEigen", 4, std::vector<std::string>{"y1", "y2", "y3", "y4"}); // 输入Eigen格式的向量
    plot.addPlot("testVector", 5);                                                  // 输入Vector格式的向量，如果不指定各个物理量的名称，则默认用数字依次编号

    float array[3];
    Eigen::Matrix<double, 4, 1> eigenVec; eigenVec.setZero();
    std::vector<int> vec(5);

    for(int i(0); i < 50; ++i){
        plot.addFrame("test", i, i+1);  // 给对应名称的Plot输入数据，输入数据的类型可以为标量、数组、Eigen格式的向量、Vector格式的向量

        array[0] = i-10;
        array[1] = i;
        array[2] = i+10;
        plot.addFrame("testArray", i, array);

        eigenVec << i-10, i, i+10, i+20;
        plot.addFrame("testEigen", eigenVec);   // 不给定x轴坐标的话，可以默认以运行该函数的时间为x轴坐标

        vec[0] = i-20;
        vec[1] = i-10;
        vec[2] = i;
        vec[3] = i+10;
        vec[4] = i+20;
        plot.addFrame("testVector", i, vec);

        usleep(100);
    }

    // plot.showPlot("test");                                           // 显示某个Plot
    // plot.showPlot("testArray");                                      
    // plot.showPlot(std::vector<std::string>{"test", "testVector"});   // 显示多个Plot
    plot.showPlotAll();                                                 // 显示全部Plot
}