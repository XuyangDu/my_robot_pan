#include "MotorSerialChain/MotorSerialChain.h"
#include "multiThread/Loop.h"
#include "sCurve/SCurve.h"
#include "time/timeMarker.h"

void setProcessScheduler(){
    pid_t pid = getpid();
    sched_param param;
    param.sched_priority = sched_get_priority_max(SCHED_FIFO);
    if (sched_setscheduler(pid, SCHED_FIFO, &param) == -1) {
        std::cout << "[ERROR] Function setProcessScheduler failed." << std::endl;
    }
}

int main(){
    setProcessScheduler();

    MotorSerialChain *chain01;
    MotorSerialChain *chain02;

    std::vector<double> zeroCmd;
    zeroCmd.push_back(0.0);
    zeroCmd.push_back(0.0);

    std::vector<int> chain01ID;
    std::vector<double> chain01W;
    std::vector<double> chain01KW;

    std::vector<int> chain02ID;
    std::vector<double> chain02W;
    std::vector<double> chain02KW;

    chain01ID.push_back(0);
    chain01ID.push_back(1);
    chain01W.push_back(0.0);
    chain01W.push_back(0.0);
    chain01KW.push_back(3.0);
    chain01KW.push_back(3.0);

    chain02ID = chain01ID;
    chain02W  = chain01W;
    chain02KW = chain01KW;

    chain01 = new MotorSerialChain("/dev/leg0serial0", 2, chain01ID);
    chain02 = new MotorSerialChain("/dev/leg0serial1", 2, chain02ID);

    chain01->setMotorCmd(zeroCmd, chain01W, zeroCmd, zeroCmd, chain01KW);
    chain02->setMotorCmd(zeroCmd, chain02W, zeroCmd, zeroCmd, chain02KW);

    LoopFunc *chain01Loop = new LoopFunc("chain01Loop", 0.002, boost::bind(&MotorSerialChain::run, chain01));
    LoopFunc *chain02Loop = new LoopFunc("chain02Loop", 0.002, boost::bind(&MotorSerialChain::run, chain02));

    chain01Loop->start();
    chain02Loop->start();

    // usleep(10000000);
    // while(true){}

    double scale = 10.0;
    SCurve sCurve;
    sCurve.setSCurve(scale, 10, 20, 40);
    double startTime = getTimeSecond();
    double currentTime = startTime;
    double endTime = startTime + sCurve.getT();
    while(currentTime < endTime){
        chain01W.at(0) =   -scale * sCurve.getDs();
        chain01W.at(1) =   -scale * sCurve.getDs();

        chain02W.at(0) = scale * sCurve.getDs();
        chain02W.at(1) = scale * sCurve.getDs();


// std::cout << "chain01W: " << chain01W.at(0) << std::endl;
// std::cout << "chain02W: " << chain02W.at(0) << std::endl;
// std::cout << "chain01KW: " << chain01KW.at(0) << std::endl;
// std::cout << "chain02KW: " << chain02KW.at(0) << std::endl;

        chain01->setMotorCmd(zeroCmd, chain01W, zeroCmd, zeroCmd, chain01KW);
        chain02->setMotorCmd(zeroCmd, chain02W, zeroCmd, zeroCmd, chain02KW);

        currentTime = getTimeSecond();
    }

    /* delete loop first, then delete chain */
    delete chain01Loop;
    delete chain02Loop;

    delete chain01;
    delete chain02;

    return 0;
}