#ifndef IOSER_H
#define IOSER_H

#include "interface/IOInterface.h"
#include "model/ArmReal.h"

class IOSER : public IOInterface{
public:
    IOSER(CmdPanel *cmdPanel);
    ~IOSER();
    bool sendRecv(const LowlevelCmd *cmd, LowlevelState *state);
    // void setGripper(double position, double force);
    // void getGripper(double &position, double &force);
private:
    IOPort *_ioPort;
    ArmReal *_armInterface;
};

#endif  // IOSER_H