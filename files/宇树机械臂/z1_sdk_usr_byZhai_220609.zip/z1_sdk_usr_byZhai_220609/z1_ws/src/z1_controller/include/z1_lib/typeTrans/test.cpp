#include <iostream>
#include <vector>
#include <Eigen/Dense>
#include "typeTrans.h"

/* Test convert */
// int main(){
//     std::cout << convert(32, 2) << std::endl;
//     std::cout << convert(32, 8) << std::endl;
//     std::cout << convert(32, 10) << std::endl;
//     std::cout << convert(15, 16) << std::endl;

//     return 0;
// }


/* just scalar number */
// std::vector<double> print(std::vector<double> &os){
//     // os.push_back(t);
//     return os;
// }

// std::vector<double> print(std::vector<double> &os, int &t){
//     os.push_back(t);
//     return os;
// }

// template<typename T, typename... Args>
// std::vector<double> print(std::vector<double> &os, const T &t, const Args&... rest){
//     os.push_back(t);
//     // print(os, t);

//     return print(os, rest...);
// }

// int main(){
//     // Eigen::Matrix2d mat22;
//     std::vector<double> vec;

//     // mat22 << 1.1, 1.2, 1.3, 1.4;

//     print(vec, 1, 4, 3, 5);
//     // print(vec, 1, 4, 3, 5, mat22);

//     for(int i(0); i<vec.size(); ++i){
//         std::cout << vec.at(i) << ", ";
//     }
// }



/* Matrix */
// void addValue(std::vector<double> &vec, double value){
//     vec.push_back(value);
// }

// void addValue(std::vector<double> &vec, Eigen::MatrixXd value){
//     for(int i(0); i<value.rows(); ++i){
//         for(int j(0); j<value.cols(); ++j){
//             vec.push_back(value(i, j));
//         }
//     }
// }

// template<typename T>
// void combineToVector(std::vector<double> &vec, T value){
//     addValue(vec, value);
// }


// template<typename T, typename... Args>
// void combineToVector(std::vector<double> &os, T t, const Args&... rest){
//     combineToVector(os, t);

//     return combineToVector(os, rest...);
// }

// int main(){
//     Eigen::Matrix2d mat22;
//     Eigen::Vector2d vec2;
//     std::vector<double> vec;
//     double a, b, c;

//     vec2 << 100, 200;
//     mat22 << 1.1, 1.2, 1.3, 1.4;

//     // print(vec, 1.0, 4.0, 3.0, 5.0);
//     combineToVector(vec, 1.0, 4.0, 3.0, 5.0, mat22, 1.0);
//     // print(vec, vec2, mat22);
//     combineToVector(vec, a, b, mat22, vec2);


//     for(int i(0); i<vec.size(); ++i){
//         std::cout << vec.at(i) << ", ";
//     }

//     std::cout << std::endl;
// }


/* vector iterator */
// int main(){
//     std::vector<double> vec;
//     vec.push_back(1.0);
//     vec.push_back(2.0);
//     vec.push_back(3.0);

//     std::vector<double>::iterator beg = vec.begin();
//     std::vector<double>::iterator end = beg;

//     ++end;
//     std::cout << end - beg << std::endl;
//     vec.erase(beg, end);

//     for(int i(0); i<vec.size(); ++i){
//         std::cout << vec.at(i) << ", ";
//     }std::cout << std::endl;

//     return 0;
// }