#include <stdio.h>
#include "UDPPort/UDPPort.h"

int main(){
    UDPPort port("192.168.123.162", 3333, 2222, 3, BlockYN::NO, 500000);
    
    uint8_t sendMsg[3] = {0xFE, 0xEE, 0x22};
    uint8_t recvMsg[1000];

    while(true){
        if(port.recv(recvMsg) == 3){
            for(int i(0); i<3; ++i){
                printf("%x \n", recvMsg[i]);
            }
            port.send(sendMsg, 3);
        }
    }


    return 0;
}