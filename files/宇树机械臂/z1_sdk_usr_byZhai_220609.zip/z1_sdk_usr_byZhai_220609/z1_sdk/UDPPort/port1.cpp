#include "UDPPort/UDPPort.h"

int main(){
    UDPPort port("192.168.123.100", 2222, 1111, 3);
    
    uint8_t sendMsg[3] = {0xFE, 0xEE, 0x11};

    port.send(sendMsg, 3);
    uint8_t recvMsg[3] = {0, 0, 0};;


    port.recv(recvMsg);

    for(int i(0); i<3; ++i){
        printf("%x \n", recvMsg[i]);
    }

    return 0;
}