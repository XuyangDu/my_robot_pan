#ifndef UNITREE_ARM_KEYBOARD_UDP_SEND_H
#define UNITREE_ARM_KEYBOARD_UDP_SEND_H

#include "CmdPanel/CmdPanel.h"
#include "UDPPort/UDPPort.h"
#include "unitree_arm_sdk/include/comm.h"


class UnitreeKeyboardUDPSend : public CmdPanel{
public:
    UnitreeKeyboardUDPSend(std::vector<KeyAction*> events, 
        EmptyAction emptyAction, size_t channelNum = 1,
        double dt = 0.002);
    ~UnitreeKeyboardUDPSend();
    std::string getString(std::string slogan);
    std::vector<double> stringToArray(std::string slogan);
    std::vector<std::vector<double> > stringToMatrix(std::string slogan);
    
private:
    // keyboard communication
    void _read();
    void _pauseKey();
    void _startKey();
    void _extractCmd();

    fd_set _set;
    char _c = '\0';

    termios _oldSettings;
    termios _newSettings;
    timeval _tv;

    // udp communication
    void _communicationUDP();
    void _extractCmdKeyboard();

    UDPPort *_udp;
    SendCmd _sendCmd;
    RecvState _recvState;
    std::vector<std::vector<double>> posture;
    std::string slogan;
};

#endif  // UNITREE_ARM_KEYBOARD_UDP_SEND_H