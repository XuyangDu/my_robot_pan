#include "UDPPort/UDPPort.h"
#include "unitree_arm_sdk/include/comm.h"

int main(){
    UDPPort udp("127.0.0.1", 8081, 8082, sizeof(RecvState), BlockYN::NO, 500000);
    
    SendCmd sendMsg;
    RecvState recvMsg;
    sendMsg = {0};
    recvMsg = {0};

    bool turn = true;
    while(true){
        if(turn){
            sendMsg.state = ArmFSMState::CARTESIAN;
            turn = false;
        }
        else{
            sendMsg.state = ArmFSMState::MOVEJ;
            turn = true;
        }
        udp.send((uint8_t*)&sendMsg, sizeof(SendCmd));
        udp.recv((uint8_t*)&recvMsg);

        // printf("%x \n", recvMsg.head[0]);
        usleep(50000);
    }
    return 0;
}