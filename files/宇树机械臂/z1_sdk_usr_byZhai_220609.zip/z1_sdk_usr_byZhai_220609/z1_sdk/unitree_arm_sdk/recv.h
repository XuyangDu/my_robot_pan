#ifndef UNITREE_ARM_KEYBOARD_UDP_RECV_H
#define UNITREE_ARM_KEYBOARD_UDP_RECV_H

#include "CmdPanel/CmdPanel.h"
#include "UDPPort/UDPPort.h"
#include "unitree_arm_sdk/include/comm.h"


class UnitreeKeyboardUDPRecv : public CmdPanel{
public:
    UnitreeKeyboardUDPRecv(std::vector<KeyAction*> events, 
        EmptyAction emptyAction, size_t channelNum = 1,
        double dt = 0.002);
    ~UnitreeKeyboardUDPRecv();
    
    SendCmd getSendCmd(){return _sendCmd;};
    RecvState getRecvState(){return _recvState;};

private:
    void _read();
    void _extractCmd();

    UDPPort *_udp;
    SendCmd _sendCmd;
    RecvState _recvState;
};

#endif  // UNITREE_ARM_KEYBOARD_UDP_RECV_H