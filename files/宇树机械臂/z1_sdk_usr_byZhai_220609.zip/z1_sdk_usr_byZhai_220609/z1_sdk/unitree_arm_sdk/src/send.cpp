#include <iostream>
#include <sstream>

#include "unitree_arm_sdk/send.h"
#include "time/timeMarker.h"
#include "mathLib/mathTools.h"
#include "common/judgeEqual.h"

UnitreeKeyboardUDPSend::UnitreeKeyboardUDPSend(std::vector<KeyAction*> events, 
    EmptyAction emptyAction, size_t channelNum, double dt)
    : CmdPanel(events, emptyAction, channelNum, dt){
    // _udp = new UDPPort("192.168.123.220", 8082, 8081, sizeof(RecvState), BlockYN::NO, 500000);
    _udp = new UDPPort("127.0.0.1", 8081, 8082, sizeof(RecvState), BlockYN::NO, 500000);

    _sendCmd = {0};
    _sendCmd.head[0] = 0xFE;
    _sendCmd.head[1] = 0xFF;
    _recvState = {0};

    tcgetattr( fileno( stdin ), &_oldSettings );
    _newSettings = _oldSettings;
    _oldSettings.c_lflag |= ( ICANON |  ECHO);
    _newSettings.c_lflag &= (~ICANON & ~ECHO);

    _startKey();
    _start();
}

UnitreeKeyboardUDPSend::~UnitreeKeyboardUDPSend(){
    _pauseKey();
    delete _udp;
}

void UnitreeKeyboardUDPSend::_extractCmd(){
    if(_c == '\033'){
        int m = read( fileno( stdin ), &_c, 1 );
        if(_c == '['){
            m = read( fileno( stdin ), &_c, 1 );
            switch (_c)
            {
            case 'A':
                _keyCmd.c = "up";
                break;
            case 'B':
                _keyCmd.c = "down";
                break;
            case 'C':
                _keyCmd.c = "right";
                break;
            case 'D':
                _keyCmd.c = "left";
                break;
            default:
                break;
            }
        }
    }
    else{
        _keyCmd.c = _c;
    }

    _pressKeyboard();
}

void UnitreeKeyboardUDPSend::_pauseKey(){
    tcsetattr( fileno( stdin ), TCSANOW, &_oldSettings );
    _running = false;
}

void UnitreeKeyboardUDPSend::_startKey(){
    tcsetattr( fileno( stdin ), TCSANOW, &_newSettings );
    _running = true;
}

void UnitreeKeyboardUDPSend::_read(){
    FD_ZERO(&_set);
    FD_SET( fileno( stdin ), &_set );

    _tv.tv_sec = 0;
    _tv.tv_usec = 40000;

    int res = 0;

    res = select( fileno( stdin )+1, &_set, NULL, NULL, &_tv);
    if(res > 0){
        int m = read( fileno( stdin ), &_c, 1 );
        _extractCmd();
    }else{
        _releaseKeyboard();
    }

    _updateState();
    _communicationUDP();
}

std::string UnitreeKeyboardUDPSend::getString(std::string slogan){
    _running = false;
    _pauseKey();

    std::string getString;
    std::cout << slogan << std::endl;
    std::getline(std::cin, getString);

    _startKey();
    _running = true;

    return getString;
}

std::vector<double> UnitreeKeyboardUDPSend::stringToArray(std::string slogan){
    _running = false;
    _pauseKey();

    std::cout << slogan << std::endl;

    std::string getString, word;              
    std::vector<double> singleLine;              

    getline(std::cin, getString);
    std::istringstream record(getString);     
    while (record >> word){        
        singleLine.push_back(atof(word.c_str()));
    }
    
    // for (auto m : singleLine)
    //     printf("%f  ", m);
    // printf("\n");

    _startKey();
    _running = true;

    return singleLine;  
}

std::vector<std::vector<double> > UnitreeKeyboardUDPSend::stringToMatrix(std::string slogan){
    _running = false;
    _pauseKey();

    std::cout << slogan << std::endl;

    std::string getString, word;              
    std::vector<double> singleLine;              
    std::vector<std::vector<double> > multiLine;     

    while (getline(std::cin, getString)){
        if (getString.size() == 0) break;    
        std::istringstream record(getString);     
        while (record >> word){        
            singleLine.push_back(atof(word.c_str()));
        }
        multiLine.push_back(singleLine);
        singleLine.clear();
    }
    
    // for (int i = 0; i < multiLine.size(); i++){
    //     for (auto m : multiLine[i])
    //         printf("%f  ", m);
    //     printf("\n");
    // }

    _startKey();
    _running = true;

    return multiLine;  
}

void UnitreeKeyboardUDPSend::_communicationUDP(){
// std::cout << "start read" << std::endl;
    _extractCmdKeyboard();

    if(_sendCmd.state == ArmFSMState::MOVEJ){
        std::cout << "[MoveJ] Type in the posture of end of arm: " << std::endl;
        posture = this->stringToMatrix("roll pitch yaw x y z");
        _sendCmd.valueUnion.moveJ.roll =  posture[0][0];
        _sendCmd.valueUnion.moveJ.pitch = posture[0][1];
        _sendCmd.valueUnion.moveJ.yaw =   posture[0][2];
        _sendCmd.valueUnion.moveJ.x =     posture[0][3];
        _sendCmd.valueUnion.moveJ.y =     posture[0][4];
        _sendCmd.valueUnion.moveJ.z =     posture[0][5];
    }else if(_sendCmd.state == ArmFSMState::MOVEL){
        std::cout << "[MoveL] Type in the posture of end of arm: " << std::endl;
        posture = this->stringToMatrix("roll pitch yaw x y z");
        _sendCmd.valueUnion.moveL.roll =  posture[0][0];
        _sendCmd.valueUnion.moveL.pitch = posture[0][1];
        _sendCmd.valueUnion.moveL.yaw =   posture[0][2];
        _sendCmd.valueUnion.moveL.x =     posture[0][3];
        _sendCmd.valueUnion.moveL.y =     posture[0][4];
        _sendCmd.valueUnion.moveL.z =     posture[0][5];
    }else if(_sendCmd.state == ArmFSMState::MOVEC){
        std::cout << "[MoveC] Type in the posture of arm: " << std::endl;
        posture = this->stringToMatrix("roll pitch yaw x y z\nroll pitch yaw x y z");
        _sendCmd.valueUnion.moveC[0].roll =  posture[0][0];
        _sendCmd.valueUnion.moveC[0].pitch = posture[0][1];
        _sendCmd.valueUnion.moveC[0].yaw =   posture[0][2];
        _sendCmd.valueUnion.moveC[0].x =     posture[0][3];
        _sendCmd.valueUnion.moveC[0].y =     posture[0][4];
        _sendCmd.valueUnion.moveC[0].z =     posture[0][5];
        _sendCmd.valueUnion.moveC[1].roll =  posture[1][0];
        _sendCmd.valueUnion.moveC[1].pitch = posture[1][1];
        _sendCmd.valueUnion.moveC[1].yaw =   posture[1][2];
        _sendCmd.valueUnion.moveC[1].x =     posture[1][3];
        _sendCmd.valueUnion.moveC[1].y =     posture[1][4];
        _sendCmd.valueUnion.moveC[1].z =     posture[1][5];
    }else if(_sendCmd.state == ArmFSMState::SAVESTATE){
        slogan = this->getString("[SaveState] Type in the label of this state:");
        strcpy(_sendCmd.valueUnion.saveState, slogan.c_str());
    }else if(_sendCmd.state == ArmFSMState::TOSTATE){
        slogan = this->getString("[ToState] Type in the label of goal:");
        strcpy(_sendCmd.valueUnion.toState, slogan.c_str());
    }else if(_sendCmd.state == ArmFSMState::TEACH){
        slogan = this->getString("[Teach] Type in the name of this recording trajectory: ");
        strcpy(_sendCmd.valueUnion.teach, slogan.c_str());
    }else if(_sendCmd.state == ArmFSMState::TEACHREPEAT){
        slogan = this->getString("[TeachRepeat] Type in the name of recorded trajectory to repeat: ");
        strcpy(_sendCmd.valueUnion.teachRepeat, slogan.c_str());
    }else{
        _sendCmd.valueUnion = {0};
    }

    _udp->send((uint8_t*)&_sendCmd, sizeof(SendCmd));
    _udp->recv((uint8_t*)&_recvState);
}

void UnitreeKeyboardUDPSend::_extractCmdKeyboard(){
    int state = getState();
    std::string value = _keyCmd.c;
    // printf("_keyCmd.c: %s\n", _keyCmd.c.c_str());

    if(state == (int)ArmFSMState::PASSIVE){_sendCmd.state = ArmFSMState::PASSIVE;}
    else if(state == (int)ArmFSMState::JOINTCTRL){_sendCmd.state = ArmFSMState::JOINTCTRL;}
    else if(state == (int)ArmFSMState::CARTESIAN){_sendCmd.state = ArmFSMState::CARTESIAN;}
    else if(state == (int)ArmFSMState::MOVEJ){_sendCmd.state = ArmFSMState::MOVEJ;}
    else if(state == (int)ArmFSMState::MOVEL){_sendCmd.state = ArmFSMState::MOVEL;}
    else if(state == (int)ArmFSMState::MOVEC){_sendCmd.state = ArmFSMState::MOVEC;}
    else if(state == (int)ArmFSMState::TRAJECTORY){_sendCmd.state = ArmFSMState::TRAJECTORY;}
    else if(state == (int)ArmFSMState::TOSTATE){_sendCmd.state = ArmFSMState::TOSTATE;}
    else if(state == (int)ArmFSMState::SAVESTATE){_sendCmd.state = ArmFSMState::SAVESTATE;}
    else if(state == (int)ArmFSMState::TEACH){_sendCmd.state = ArmFSMState::TEACH;}
    else if(state == (int)ArmFSMState::TEACHREPEAT){_sendCmd.state = ArmFSMState::TEACHREPEAT;}
    else if(state == (int)ArmFSMState::CALIBRATION){_sendCmd.state = ArmFSMState::CALIBRATION;}
    else if(state == (int)ArmFSMState::DANCE00){_sendCmd.state = ArmFSMState::DANCE00;}
    else if(state == (int)ArmFSMState::DANCE01){_sendCmd.state = ArmFSMState::DANCE01;}
    else if(state == (int)ArmFSMState::BACKTOSTART){_sendCmd.state = ArmFSMState::BACKTOSTART;}
    else if(state == (int)ArmFSMState::GRIPPER_OPEN){_sendCmd.state = ArmFSMState::GRIPPER_OPEN;}
    else if(state == (int)ArmFSMState::GRIPPER_CLOSE){_sendCmd.state = ArmFSMState::GRIPPER_CLOSE;}
    else if(state == (int)ArmFSMState::NEXT){_sendCmd.state = ArmFSMState::NEXT;}
    else if(value == "q"){ _sendCmd.value = ArmFSMValue::Q;}
    else if(value == "w"){ _sendCmd.value = ArmFSMValue::W;}
    else if(value == "e"){ _sendCmd.value = ArmFSMValue::E;}
    else if(value == "r"){ _sendCmd.value = ArmFSMValue::R;}
    else if(value == "t"){ _sendCmd.value = ArmFSMValue::T;}
    else if(value == "y"){ _sendCmd.value = ArmFSMValue::Y;}
    else if(value == "a"){ _sendCmd.value = ArmFSMValue::A;}
    else if(value == "s"){ _sendCmd.value = ArmFSMValue::S;}
    else if(value == "d"){ _sendCmd.value = ArmFSMValue::D;}
    else if(value == "f"){ _sendCmd.value = ArmFSMValue::F;}
    else if(value == "g"){ _sendCmd.value = ArmFSMValue::G;}
    else if(value == "h"){ _sendCmd.value = ArmFSMValue::H;}
    else if(value == "down"){ _sendCmd.value = ArmFSMValue::DOWN;}
    else if(value == "up"){ _sendCmd.value = ArmFSMValue::UP;}
    else{
        _sendCmd.state = ArmFSMState::INVALID;
        _sendCmd.value = ArmFSMValue::INVALID;
        return;
    }
}