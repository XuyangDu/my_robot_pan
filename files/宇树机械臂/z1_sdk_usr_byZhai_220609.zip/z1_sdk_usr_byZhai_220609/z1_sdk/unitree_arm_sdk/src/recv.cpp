#include "unitree_arm_sdk/recv.h"


UnitreeKeyboardUDPRecv::UnitreeKeyboardUDPRecv(std::vector<KeyAction*> events, 
    EmptyAction emptyAction, size_t channelNum, double dt)
    : CmdPanel(events, emptyAction, channelNum, dt){
    // _udp = new UDPPort("192.168.123.220", 8082, 8081, sizeof(RecvState), BlockYN::NO, 500000);
    _udp = new UDPPort("127.0.0.1", 8082, 8081, sizeof(SendCmd), BlockYN::NO, 500000);

    _sendCmd = {0};
    _recvState = {0};

    _start();
}

UnitreeKeyboardUDPRecv::~UnitreeKeyboardUDPRecv(){
    delete _udp;
}

void UnitreeKeyboardUDPRecv::_read(){
// std::cout << "start read" << std::endl;
    _udp->send((uint8_t*)&_recvState, sizeof(RecvState));
    SendCmd tmpSendCmd;
    size_t len;
    len = _udp->recv((uint8_t*)&tmpSendCmd);
    if(len == sizeof(SendCmd)){
        if((tmpSendCmd.head[0] == 0xFE) && (tmpSendCmd.head[1] == 0xFF)){
            _sendCmd.state = tmpSendCmd.state;
            _sendCmd.value = tmpSendCmd.value;

            if(_sendCmd.state == ArmFSMState::MOVEJ){
                _sendCmd = tmpSendCmd;
                std::cout << "_sendCmd:" << std::endl;
                std::cout << " " << _sendCmd.valueUnion.moveJ.roll;
                std::cout << " " << _sendCmd.valueUnion.moveJ.pitch;
                std::cout << " " << _sendCmd.valueUnion.moveJ.yaw;
                std::cout << " " << _sendCmd.valueUnion.moveJ.x;
                std::cout << " " << _sendCmd.valueUnion.moveJ.y;
                std::cout << " " << _sendCmd.valueUnion.moveJ.z;
                std::cout << std::endl;
            }else if(_sendCmd.state == ArmFSMState::MOVEL){
                _sendCmd = tmpSendCmd;
                std::cout << "_sendCmd:" << std::endl;
                std::cout << " " << _sendCmd.valueUnion.moveL.roll;
                std::cout << " " << _sendCmd.valueUnion.moveL.pitch;
                std::cout << " " << _sendCmd.valueUnion.moveL.yaw;
                std::cout << " " << _sendCmd.valueUnion.moveL.x;
                std::cout << " " << _sendCmd.valueUnion.moveL.y;
                std::cout << " " << _sendCmd.valueUnion.moveL.z;
                std::cout << std::endl;
            }else if(_sendCmd.state == ArmFSMState::MOVEC){
                _sendCmd = tmpSendCmd;
                std::cout << "_sendCmd:" << std::endl;
                std::cout << " " << _sendCmd.valueUnion.moveC[0].roll;
                std::cout << " " << _sendCmd.valueUnion.moveC[0].pitch;
                std::cout << " " << _sendCmd.valueUnion.moveC[0].yaw;
                std::cout << " " << _sendCmd.valueUnion.moveC[0].x;
                std::cout << " " << _sendCmd.valueUnion.moveC[0].y;
                std::cout << " " << _sendCmd.valueUnion.moveC[0].z;
                std::cout << std::endl;
                std::cout << "_sendCmd:" << std::endl;
                std::cout << " " << _sendCmd.valueUnion.moveC[1].roll;
                std::cout << " " << _sendCmd.valueUnion.moveC[1].pitch;
                std::cout << " " << _sendCmd.valueUnion.moveC[1].yaw;
                std::cout << " " << _sendCmd.valueUnion.moveC[1].x;
                std::cout << " " << _sendCmd.valueUnion.moveC[1].y;
                std::cout << " " << _sendCmd.valueUnion.moveC[1].z;
                std::cout << std::endl;
            }else if(_sendCmd.state == ArmFSMState::TOSTATE){
                _sendCmd = tmpSendCmd;
                std::cout << "state: " << _sendCmd.valueUnion.toState << std::endl;
            }else if(_sendCmd.state == ArmFSMState::SAVESTATE){
                _sendCmd = tmpSendCmd;
                std::cout << "state: " << _sendCmd.valueUnion.saveState << std::endl;
            }
            else if(_sendCmd.state == ArmFSMState::TEACH){
                _sendCmd = tmpSendCmd;
                std::cout << "state: " << _sendCmd.valueUnion.teach << std::endl;
            }
            else if(_sendCmd.state == ArmFSMState::TEACHREPEAT){
                _sendCmd = tmpSendCmd;
                std::cout << "state: " << _sendCmd.valueUnion.teachRepeat << std::endl;
            }
        }else{
            std::cout << "[Warning] The received data is wrong from UDP "<< std::endl;
        }
    }

    _extractCmd();
    _updateState();

    // usleep(2000);
}

void UnitreeKeyboardUDPRecv::_extractCmd(){
    if (_sendCmd.state  == ArmFSMState::BACKTOSTART){     _keyCmd.c = "`"; }
    else if(_sendCmd.state  == ArmFSMState::PASSIVE){     _keyCmd.c = "1"; }
    else if(_sendCmd.state  == ArmFSMState::JOINTCTRL){   _keyCmd.c = "2"; }
    else if(_sendCmd.state  == ArmFSMState::CARTESIAN){   _keyCmd.c = "3"; }
    else if(_sendCmd.state  == ArmFSMState::MOVEJ){       _keyCmd.c = "4"; }
    else if(_sendCmd.state  == ArmFSMState::MOVEL){       _keyCmd.c = "5"; }
    else if(_sendCmd.state  == ArmFSMState::MOVEC){       _keyCmd.c = "6"; }
    else if(_sendCmd.state  == ArmFSMState::TEACH){       _keyCmd.c = "7"; }
    else if(_sendCmd.state  == ArmFSMState::TEACHREPEAT){ _keyCmd.c = "8"; }
    else if(_sendCmd.state  == ArmFSMState::SAVESTATE){   _keyCmd.c = "9"; }
    else if(_sendCmd.state  == ArmFSMState::TOSTATE){     _keyCmd.c = "0"; }
    else if(_sendCmd.state  == ArmFSMState::TRAJECTORY){  _keyCmd.c = "-"; }
    else if(_sendCmd.state  == ArmFSMState::CALIBRATION){ _keyCmd.c = "="; }
    else if(_sendCmd.state  == ArmFSMState::NEXT){        _keyCmd.c = "]"; }
    else if(_sendCmd.value  == ArmFSMValue::Q){ _keyCmd.c = "q"; }
    else if(_sendCmd.value  == ArmFSMValue::W){ _keyCmd.c = "w"; }
    else if(_sendCmd.value  == ArmFSMValue::E){ _keyCmd.c = "e"; }
    else if(_sendCmd.value  == ArmFSMValue::R){ _keyCmd.c = "r"; }
    else if(_sendCmd.value  == ArmFSMValue::T){ _keyCmd.c = "t"; }
    else if(_sendCmd.value  == ArmFSMValue::Y){ _keyCmd.c = "y"; }
    else if(_sendCmd.value  == ArmFSMValue::A){ _keyCmd.c = "a"; }
    else if(_sendCmd.value  == ArmFSMValue::S){ _keyCmd.c = "s"; }
    else if(_sendCmd.value  == ArmFSMValue::D){ _keyCmd.c = "d"; }
    else if(_sendCmd.value  == ArmFSMValue::F){ _keyCmd.c = "f"; }
    else if(_sendCmd.value  == ArmFSMValue::G){ _keyCmd.c = "g"; }
    else if(_sendCmd.value  == ArmFSMValue::H){ _keyCmd.c = "h"; }
    else if(_sendCmd.value  == ArmFSMValue::DOWN){ _keyCmd.c = "down"; }
    else if(_sendCmd.value  == ArmFSMValue::UP){ _keyCmd.c = "up"; }
    else{
        _releaseKeyboard();
        return;
    }

// std::cout << "state:" << (int)_sendCmd.state << std::endl;
// std::cout << "value:" << (int)_sendCmd.value << std::endl;
    _pressKeyboard();
}