#include "UDPPort/UDPPort.h"
#include "unitree_arm_sdk/include/comm.h"

int main(){
    UDPPort udp("127.0.0.1", 8081, 8082, sizeof(SendCmd), BlockYN::NO, 500000);
    
    SendCmd sendMsg;
    RecvState recvMsg;
    sendMsg = {0};
    recvMsg = {0};

    while(true){
        udp.send((uint8_t*)&recvMsg, sizeof(RecvState));
        udp.recv((uint8_t*)&sendMsg);

        printf("%d \n", (int)sendMsg.state);
        usleep(50000);
    }
    return 0;
}