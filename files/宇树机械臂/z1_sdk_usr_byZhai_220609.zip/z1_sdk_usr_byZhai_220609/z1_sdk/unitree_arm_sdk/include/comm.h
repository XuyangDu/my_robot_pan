/*****************************************************************
Copyright (c) 2022, Unitree Robotics.Co.Ltd. All rights reserved.
*****************************************************************/
#ifndef UNITREE_ARM_COMM_H
#define UNITREE_ARM_COMM_H

#include <stdint.h>

#pragma pack(1)

enum class ArmFSMState{
    INVALID,
    PASSIVE,
    JOINTCTRL,
    CARTESIAN,
    MOVEJ,
    MOVEL,
    MOVEC,
    TRAJECTORY,
    TOSTATE,
    SAVESTATE,
    TEACH,
    TEACHREPEAT,
    CALIBRATION,
    DANCE00,
    DANCE01,
    DANCE02,
    DANCE03,
    DANCE04,
    DANCE05,
    DANCE06,
    DANCE07,
    DANCE08,
    DANCE09,
    BACKTOSTART,
    GRIPPER_OPEN,
    GRIPPER_CLOSE,
    NEXT
};

enum class ArmFSMValue{
    INVALID,
    Q,A,
    W,S,  
    E,D,
    R,F,
    T,G, 
    Y,H,   
    DOWN,
    UP
};

// 20 Byte
struct JointCmd{
    float T;
    float W;
    float Pos;
    float K_P;
    float K_W;
};

// 16 Byte
struct JointState{
    float T;
    float W;
    float Acc;
    float Pos;
};

union UDPSendCmd{
    uint8_t checkCmd;
    JointCmd jointCmd[7];
};

union UDPRecvState{
    uint8_t singleState;
    uint8_t selfCheck[10];
    JointState jointState[7];
    uint8_t errorCheck[16];
};

// 48 Byte
struct Posture{
    double roll;
    double pitch;
    double yaw;
    double x;
    double y;
    double z;
};

// 48 Byte
struct MoveC{
    Posture middlePosture;
    Posture endPosture;
};

// 96 Byte
union ValueUnion{
    Posture moveJ;
    Posture moveL;
    Posture moveC[2];
    char teach[10];
    char teachRepeat[10];
    char saveState[10];
    char toState[10];
};

// 2+4+96 = 102 Byte
struct SendCmd{
    uint8_t head[2];
    ArmFSMState state;
    ArmFSMValue value;
    ValueUnion valueUnion;
};

// 2+112+24 = 138 Byte
struct RecvState{
    uint8_t head[2];
    JointState jointState[7];
    Posture cartesianState;
};

#pragma pack()

#endif  // UNITREE_ARM_COMM_H_
